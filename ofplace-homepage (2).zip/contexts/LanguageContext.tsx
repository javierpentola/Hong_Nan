"use client"

import type React from "react"
import { createContext, useContext, useState } from "react"
import { translations, type Language } from "../utils/translations"
import { translations_2, type Language_2 } from "../utils/translations_2"

type LanguageContextType = {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: keyof (typeof translations)["en"] | keyof (typeof translations_2)["en"]) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>("en")

  const t = (key: keyof (typeof translations)["en"] | keyof (typeof translations_2)["en"]) => {
    if (key in translations[language]) {
      return translations[language][key as keyof (typeof translations)[typeof language]]
    } else if (key in translations_2[language as Language_2]) {
      return translations_2[language as Language_2][key as keyof (typeof translations_2)[Language_2]]
    }
    return key // Fallback to key if translation is not found
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export const useLanguage = () => {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

