"use client"

import { AnimationManager } from "./components/AnimationManager"
import { ModalManager } from "./components/ModalManager"
import { MainContent } from "./components/MainContent"
import { LanguageProvider } from "./contexts/LanguageContext"
import { Assistance } from "./components/Assistance"

export default function Home() {
  return (
    <LanguageProvider>
      <AnimationManager>
        {(animationStep, startAnimation) => (
          <ModalManager>
            {(openModal) => (
              <MainContent openModal={openModal} animationStep={animationStep} startAnimation={startAnimation} />
            )}
          </ModalManager>
        )}
      </AnimationManager>
    </LanguageProvider>
  )
}

