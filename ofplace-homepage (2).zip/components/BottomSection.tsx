"use client"

import React from "react"
import { useLanguage } from "../contexts/LanguageContext"

interface BottomSectionProps {
  animationStep: number
}

export function BottomSection({ animationStep }: BottomSectionProps) {
  const { t } = useLanguage()

  return (
    <div className="flex flex-col md:flex-row justify-between items-center text-base md:text-xl mb-10 md:mb-20 font-['Saira'] tracking-wider mobile-text-center">
      <div
        className={`mb-4 md:mb-0 hover:opacity-70 transition-all duration-500 text-center ${
          animationStep >= 8 ? "-translate-x-full opacity-0" : ""
        }`}
      >
        {t("humanConnection")
          .split("\n")
          .map((line, index) => (
            <React.Fragment key={index}>
              {line}
              {index === 0 && <br />}
            </React.Fragment>
          ))}
      </div>
      <div
        className={`hover:opacity-70 transition-all duration-500 text-center ${
          animationStep >= 9 ? "translate-x-full opacity-0" : ""
        }`}
      >
        {t("timelessDesigns")
          .split("\n")
          .map((line, index) => (
            <React.Fragment key={index}>
              {line}
              {index === 0 && <br />}
            </React.Fragment>
          ))}
      </div>
    </div>
  )
}

