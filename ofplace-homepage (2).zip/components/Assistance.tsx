import { useLanguage } from "../contexts/LanguageContext"
import { Users, PhoneCall, MessageSquare, DollarSign } from "lucide-react"

export function Assistance() {
  const { t } = useLanguage()

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)] p-8">
      <h1
        className="text-4xl font-bold mb-6 transition-transform duration-300 ease-in-out hover:scale-105"
        dangerouslySetInnerHTML={{ __html: t("assistanceTitle") }}
      />
      <p
        className="text-xl mb-8 max-w-2xl text-center transition-opacity duration-300 ease-in-out hover:opacity-80"
        dangerouslySetInnerHTML={{ __html: t("assistanceDescription") }}
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <div className="flex items-center gap-3 mb-4">
            <Users className="w-6 h-6" />
            <h2 className="text-2xl font-bold">{t("ownAssistanceTitle")}</h2>
          </div>
          <p>{t("ownAssistanceDescription")}</p>
          <ul className="mt-4 space-y-2">
            <li>{t("phoneSupport")}</li>
            <li>{t("chatSupport")}</li>
            <li>{t("knowledgeBase")}</li>
            <li>{t("communityForums")}</li>
          </ul>
        </div>
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <div className="flex items-center gap-3 mb-4">
            <PhoneCall className="w-6 h-6" />
            <h2 className="text-2xl font-bold">{t("findAssistanceTitle")}</h2>
          </div>
          <p>{t("findAssistanceDescription")}</p>
          <ul className="mt-4 space-y-2">
            {t("assistanceProvidersList").map((provider: string, index: number) => (
              <li key={index}>{provider}</li>
            ))}
          </ul>
        </div>
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <div className="flex items-center gap-3 mb-4">
            <MessageSquare className="w-6 h-6" />
            <h2 className="text-2xl font-bold">{t("whyChooseUs")}</h2>
          </div>
          <ul className="mt-4 space-y-2">
            {t("whyChooseUsList").map((reason: string, index: number) => (
              <li key={index}>{reason}</li>
            ))}
          </ul>
        </div>
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <div className="flex items-center gap-3 mb-4">
            <DollarSign className="w-6 h-6" />
            <h2 className="text-2xl font-bold">{t("bestPricing")}</h2>
          </div>
          <p>{t("bestPricingDescription")}</p>
        </div>
      </div>
    </div>
  )
}

