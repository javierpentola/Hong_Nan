import type React from "react"
import { useState, useCallback } from "react"

interface AnimationManagerProps {
  children: (animationStep: number, startAnimation: () => void) => React.ReactNode
}

export function AnimationManager({ children }: AnimationManagerProps) {
  const [animationStep, setAnimationStep] = useState(0)
  const [animating, setAnimating] = useState(false)

  const startAnimation = useCallback(() => {
    if (animating) return
    setAnimating(true)
    setAnimationStep(0) // Reset animation step first

    const totalSteps = 15 // Updated to 15 steps
    for (let step = 1; step <= totalSteps; step++) {
      setTimeout(() => {
        setAnimationStep(step)
        if (step === totalSteps) {
          setAnimating(false)
        }
      }, step * 500) // 500ms delay between each step
    }
  }, [animating])

  return <>{children(animationStep, startAnimation)}</>
}

