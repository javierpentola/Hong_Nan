"use client"

import { useState } from "react"
import { Navigation } from "./Navigation"
import { TopSection } from "./TopSection"
import { CentralLogo } from "./CentralLogo"
import { BottomSection } from "./BottomSection"
import { Footer } from "./Footer"
import { SecondPage } from "./SecondPage"

interface MainContentProps {
  openModal: (modalName: string) => void
  animationStep: number
  startAnimation: () => void
}

export function MainContent({ openModal, animationStep, startAnimation }: MainContentProps) {
  const [showSecondPage, setShowSecondPage] = useState(false)

  const handleStartAnimation = () => {
    startAnimation()
    setTimeout(() => {
      setShowSecondPage(true)
    }, 7500)
  }

  return (
    <main className="min-h-screen bg-white text-black">
      {!showSecondPage ? (
        <div className="flex flex-col justify-between p-4 min-h-screen mobile-padding">
          <Navigation openModal={openModal} animationStep={animationStep} />
          <TopSection animationStep={animationStep} />
          <CentralLogo startAnimation={handleStartAnimation} animationStep={animationStep} />
          <BottomSection animationStep={animationStep} />
          <Footer openModal={openModal} animationStep={animationStep} />
        </div>
      ) : (
        <SecondPage initialActiveSection="home" onSoftwareClick={() => setShowSecondPage(true)} />
      )}
    </main>
  )
}

