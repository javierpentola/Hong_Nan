import { useLanguage } from "../contexts/LanguageContext"
import { Mail, Phone, MapPin } from "lucide-react"

export function Contact() {
  const { t } = useLanguage()

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)] p-8">
      <h1
        className="text-4xl font-bold mb-6 transition-transform duration-300 ease-in-out hover:scale-105"
        dangerouslySetInnerHTML={{ __html: t("contactTitle") }}
      />
      <p
        className="text-xl mb-8 max-w-2xl text-center transition-opacity duration-300 ease-in-out hover:opacity-80"
        dangerouslySetInnerHTML={{ __html: t("contactDescription") }}
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <h2 className="text-2xl font-bold mb-4">{t("getInTouch")}</h2>
          <ul className="space-y-4">
            <li className="flex items-center">
              <Mail className="mr-2" />
              <a href="mailto:contact@hongnan.com" className="hover:underline">
                contact@hongnan.com
              </a>
            </li>
            <li className="flex items-center">
              <Phone className="mr-2" />
              <a href="tel:+1234567890" className="hover:underline">
                +1 (234) 567-890
              </a>
            </li>
            <li className="flex items-center">
              <MapPin className="mr-2" />
              <span>123 Digital Avenue, Tech City, 12345</span>
            </li>
          </ul>
        </div>
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <h2 className="text-2xl font-bold mb-4">{t("sendMessage")}</h2>
          <form className="space-y-4">
            <div>
              <label htmlFor="name" className="block mb-1">
                {t("name")}
              </label>
              <input type="text" id="name" name="name" className="w-full border-2 border-black p-2" required />
            </div>
            <div>
              <label htmlFor="email" className="block mb-1">
                {t("email")}
              </label>
              <input type="email" id="email" name="email" className="w-full border-2 border-black p-2" required />
            </div>
            <div>
              <label htmlFor="cv" className="block mb-1">
                {t("cv")}
              </label>
              <input type="file" id="cv" name="cv" accept=".pdf" className="w-full border-2 border-black p-2" />
            </div>
            <div>
              <label htmlFor="message" className="block mb-1">
                {t("message")}
              </label>
              <textarea
                id="message"
                name="message"
                rows={4}
                className="w-full border-2 border-black p-2"
                required
              ></textarea>
            </div>
            <button type="submit" className="bg-black text-white px-4 py-2 hover:bg-opacity-80 transition-colors">
              {t("send")}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

