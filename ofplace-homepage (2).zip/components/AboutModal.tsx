import React from "react"
import { useLanguage } from "../contexts/LanguageContext"

export function AboutModal() {
  const { t } = useLanguage()

  return (
    <div className="space-y-4">
      <p className="text-lg">{t("aboutUsDescription")}</p>
      <div>
        <h3 className="font-bold mb-2">{t("ourValues")}</h3>
        <ul className="list-disc pl-5 space-y-2">
          {t("valuesList").map((value: string, index: number) => (
            <li key={index}>{value}</li>
          ))}
        </ul>
      </div>
    </div>
  )
}

