import React from "react"
import { useLanguage } from "../contexts/LanguageContext"

export function OurFocusModal() {
  const { t } = useLanguage()

  return (
    <div>
      <p className="mb-4">{t("ourFocusDescription")}</p>
      <ul className="list-disc pl-5">
        {t("ourFocusList").map((item, index) => (
          <li key={index} className="mb-2">
            {item}
          </li>
        ))}
      </ul>
    </div>
  )
}

