"use client"

import { useLanguage } from "../contexts/LanguageContext"
import { translations_3 } from "../utils/translations_3"
import { Code, Smartphone, Globe, Database, Cloud, Lock } from "lucide-react"

export function Software() {
  const { language } = useLanguage()
  const t = translations_3[language as keyof typeof translations_3].softwareServices

  const areas = [
    { icon: Globe, title: t.webDevelopment.title, description: t.webDevelopment.description },
    { icon: Smartphone, title: t.mobileDevelopment.title, description: t.mobileDevelopment.description },
    { icon: Database, title: t.databaseManagement.title, description: t.databaseManagement.description },
    { icon: Cloud, title: t.cloudServices.title, description: t.cloudServices.description },
    { icon: Code, title: t.customSoftware.title, description: t.customSoftware.description },
    { icon: Lock, title: t.cybersecurity.title, description: t.cybersecurity.description },
  ]

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)] p-8">
      <h1
        className="text-4xl font-bold mb-6 transition-transform duration-300 ease-in-out hover:scale-105"
        dangerouslySetInnerHTML={{ __html: t.title }}
      />
      <p className="text-xl mb-8 max-w-2xl text-center transition-opacity duration-300 ease-in-out hover:opacity-80">
        {t.description}
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl w-full">
        {areas.map((area, index) => (
          <div
            key={index}
            className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105"
          >
            <div className="flex items-center mb-4">
              <area.icon className="w-6 h-6 mr-2" />
              <h2 className="text-2xl font-bold">{area.title}</h2>
            </div>
            <p>{area.description}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

