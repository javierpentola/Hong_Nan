"use client"
import { useLanguage } from "../contexts/LanguageContext"
import type { Language } from "../utils/translations"

interface FooterProps {
  openModal: (modalName: string) => void
  animationStep: number
}

export function Footer({ openModal, animationStep }: FooterProps) {
  const { t, setLanguage, language } = useLanguage()

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang)
  }

  return (
    <footer className="flex flex-col md:flex-row justify-between items-center w-full font-['Saira'] tracking-wider">
      <button
        onClick={() => openModal("pricing")}
        className={`px-4 py-2 border-2 border-black hover:bg-black hover:text-white transition-all duration-500 mb-4 md:mb-0 ${
          animationStep >= 4 ? "-translate-x-full opacity-0" : ""
        }`}
      >
        {t("pricing")}
      </button>

      <div
        className={`flex gap-4 mb-4 md:mb-0 transition-all duration-500 ${
          animationStep >= 10 ? "translate-y-full opacity-0" : ""
        }`}
      >
        <button
          className={`px-2 py-1 hover:opacity-70 transition-opacity text-sm ${language === "en" ? "font-bold" : ""}`}
          onClick={() => handleLanguageChange("en")}
        >
          EN
        </button>
        <button
          className={`px-2 py-1 hover:opacity-70 transition-opacity text-sm ${language === "es" ? "font-bold" : ""}`}
          onClick={() => handleLanguageChange("es")}
        >
          ES
        </button>
        <button
          className={`px-2 py-1 hover:opacity-70 transition-opacity text-sm ${language === "zh" ? "font-bold" : ""}`}
          onClick={() => handleLanguageChange("zh")}
        >
          中文
        </button>
      </div>

      <button
        onClick={() => openModal("testimonials")}
        className={`px-4 py-2 border-2 border-black hover:bg-black hover:text-white transition-all duration-500 ${
          animationStep >= 5 ? "translate-x-full opacity-0" : ""
        }`}
      >
        {t("testimonials")}
      </button>
    </footer>
  )
}

