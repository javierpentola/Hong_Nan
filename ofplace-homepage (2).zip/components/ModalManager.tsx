import type React from "react"
import { useState } from "react"
import { Modal } from "./Modal"

interface ModalManagerProps {
  children: (openModal: (modalName: string) => void) => React.ReactNode
}

export function ModalManager({ children }: ModalManagerProps) {
  const [activeModal, setActiveModal] = useState<string | null>(null)

  const openModal = (modalName: string) => {
    setActiveModal(modalName)
  }

  const closeModal = () => {
    setActiveModal(null)
  }

  return (
    <>
      {children(openModal)}
      <Modal isOpen={activeModal === "about"} onClose={closeModal} variant="about" />
      <Modal isOpen={activeModal === "services"} onClose={closeModal} variant="services" />
      <Modal isOpen={activeModal === "pricing"} onClose={closeModal} variant="pricing" />
      <Modal isOpen={activeModal === "testimonials"} onClose={closeModal} variant="testimonials" />
      <Modal isOpen={activeModal === "ourFocus"} onClose={closeModal} variant="ourFocus" />
    </>
  )
}

