"use client"

import React from "react"
import { useLanguage } from "../contexts/LanguageContext"

interface TopSectionProps {
  animationStep: number
}

export function TopSection({ animationStep }: TopSectionProps) {
  const { t } = useLanguage()

  return (
    <div className="flex flex-col md:flex-row justify-between items-center text-base md:text-xl mt-10 md:mt-20 font-['Saira'] tracking-wider mobile-text-center">
      <div
        className={`mb-4 md:mb-0 hover:opacity-70 transition-all duration-500 text-center z-20 ${
          animationStep >= 6 ? "-translate-x-full opacity-0" : ""
        }`}
      >
        {t("creativeSolutions")
          .split("\n")
          .map((line, index) => (
            <React.Fragment key={index}>
              {line}
              {index === 0 && <br />}
            </React.Fragment>
          ))}
      </div>
      <div
        className={`mb-4 md:mb-0 hover:opacity-70 transition-all duration-500 text-center z-20 ${
          animationStep >= 12 ? "-translate-y-full opacity-0" : ""
        }`}
      >
        {t("tailoredTalent")
          .split("\n")
          .map((line, index) => (
            <React.Fragment key={index}>
              {line}
              {index === 0 && <br />}
            </React.Fragment>
          ))}
      </div>
      <div
        className={`hover:opacity-70 transition-all duration-500 text-center z-20 ${
          animationStep >= 7 ? "translate-x-full opacity-0" : ""
        }`}
      >
        {t("precisionCrafted")
          .split("\n")
          .map((line, index) => (
            <React.Fragment key={index}>
              {line}
              {index === 0 && <br />}
            </React.Fragment>
          ))}
      </div>
    </div>
  )
}

