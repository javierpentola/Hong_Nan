"use client"

import React, { useState } from "react"
import { useLanguage } from "../contexts/LanguageContext"

interface CentralLogoProps {
  startAnimation: () => void
  animationStep: number
}

export function CentralLogo({ startAnimation, animationStep }: CentralLogoProps) {
  const [isHovered, setIsHovered] = useState(false)
  const { t, language } = useLanguage()

  return (
    <div className="relative flex flex-col items-center justify-center my-10 md:my-20">
      <div
        className={`relative text-center z-20 flex flex-col items-center gap-4 transition-all duration-500 ${
          animationStep >= 13 ? "opacity-0" : ""
        }`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <span className="text-4xl md:text-[8vw] leading-none font-['Noto_Sans_SC'] font-light cursor-pointer">
          ://红南智联未来
        </span>
        <span className="font-['Saira'] text-xl md:text-2xl tracking-wide">
          {language === "zh" ? "红南" : "Hong Nan"}
        </span>
      </div>
      <div className="absolute w-full md:w-[80vw] max-w-[600px] aspect-square overflow-visible flex items-center justify-center z-10">
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Mesa%20de%20trabajo%201-gpi4VYaa7WEPWa6uKDccdFUDZqdspA.svg"
          alt="Logo overlay"
          className={`w-full h-full object-contain transition-opacity duration-500 ${
            (animationStep >= 1 && animationStep < 14) || isHovered ? "opacity-100" : "opacity-0"
          }`}
          style={{ filter: "brightness(1)" }}
        />
      </div>
      <button
        className={`hover:opacity-70 transition-all duration-300 text-center cursor-pointer z-30 mt-10 md:mt-20 font-['Saira'] tracking-wide ${
          animationStep >= 11 ? "translate-y-full opacity-0" : ""
        }`}
        onClick={startAnimation}
      >
        {t("clickToContinue")
          .split("\n")
          .map((line, index) => (
            <React.Fragment key={index}>
              <strong>{line}</strong>
              {index === 0 && <br />}
            </React.Fragment>
          ))}
      </button>
    </div>
  )
}

