import { useLanguage } from "../contexts/LanguageContext"
import { Megaphone, Target, BarChart, Award } from "lucide-react"

export function Marketing() {
  const { t } = useLanguage()

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)] p-8">
      <h1
        className="text-4xl font-bold mb-6 transition-transform duration-300 ease-in-out hover:scale-105"
        dangerouslySetInnerHTML={{ __html: t("marketingTitle") }}
      />
      <p
        className="text-xl mb-8 max-w-2xl text-center transition-opacity duration-300 ease-in-out hover:opacity-80"
        dangerouslySetInnerHTML={{ __html: t("marketingDescription") }}
      />

      {/* Main content with a different layout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl w-full">
        <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <div className="flex items-center gap-3 mb-4">
              <Megaphone className="w-6 h-6" />
              <h2 className="text-2xl font-bold">{t("strategicMarketing")}</h2>
            </div>
            <p>{t("strategicMarketingDescription")}</p>
          </div>
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <div className="flex items-center gap-3 mb-4">
              <Target className="w-6 h-6" />
              <h2 className="text-2xl font-bold">{t("targetedCampaigns")}</h2>
            </div>
            <p>{t("targetedCampaignsDescription")}</p>
          </div>
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <div className="flex items-center gap-3 mb-4">
              <BarChart className="w-6 h-6" />
              <h2 className="text-2xl font-bold">{t("dataAnalytics")}</h2>
            </div>
            <p>{t("dataAnalyticsDescription")}</p>
          </div>
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <div className="flex items-center gap-3 mb-4">
              <Award className="w-6 h-6" />
              <h2 className="text-2xl font-bold">{t("brandBuilding")}</h2>
            </div>
            <p>{t("brandBuildingDescription")}</p>
          </div>
        </div>
        <div className="md:col-span-1 border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <h3 className="text-2xl font-bold mb-4 transition-transform duration-300 ease-in-out hover:scale-105">
            {t("marketingServices")}
          </h3>
          <ul className="space-y-2">
            {t("marketingServicesList").map((service: string, index: number) => (
              <li
                key={index}
                className="p-2 border-b border-gray-200 last:border-b-0 transition-all duration-300 ease-in-out hover:bg-gray-50"
              >
                {service}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}

