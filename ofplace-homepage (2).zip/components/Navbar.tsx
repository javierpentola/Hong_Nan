import { useEffect, useState } from "react"
import { useLanguage } from "../contexts/LanguageContext"
import { Menu, X } from "lucide-react"

interface NavbarProps {
  onQuickStart: () => void
  onHomeClick: () => void
  onAboutUsClick: () => void
  onContactClick: () => void
  onSoftwareClick: () => void
  onDesignClick: () => void
  onWritingClick: () => void
  onMarketingClick: () => void
  onSocialMediaClick: () => void
  onTranslationClick: () => void
  onAssistanceClick: () => void
  onVideoClick: () => void
  onEducationClick: () => void
  activeSection:
    | "home"
    | "aboutUs"
    | "contact"
    | "quickStart"
    | "software"
    | "design"
    | "writing"
    | "marketing"
    | "socialMedia"
    | "translation"
    | "assistance"
    | "video"
    | "education"
    | null
}

export default function Navbar({
  onQuickStart,
  onHomeClick,
  onAboutUsClick,
  onContactClick,
  onSoftwareClick,
  onDesignClick,
  onWritingClick,
  onMarketingClick,
  onSocialMediaClick,
  onTranslationClick,
  onAssistanceClick,
  onVideoClick,
  onEducationClick,
  activeSection,
}: NavbarProps) {
  const [isVisible, setIsVisible] = useState(false)
  const { t, language, setLanguage } = useLanguage()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 500)
    return () => clearTimeout(timer)
  }, [])

  const handleLanguageChange = (lang: "en" | "es" | "zh") => {
    setLanguage(lang)
  }

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  const handleNavClick = (callback: () => void) => {
    callback()
    setIsMenuOpen(false)
  }

  return (
    <nav
      className={`fixed top-0 left-0 w-full bg-white z-50 transition-all duration-1000 
      ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-full"}`}
    >
      <div className="border-2 border-black">
        {/* Main navbar container */}
        <div className="flex flex-col md:flex-row">
          {/* Logo section */}
          <div className="w-full md:w-24 h-16 md:h-24 border-b-2 md:border-b-0 md:border-r-2 border-black flex items-center justify-between md:justify-center p-4">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Mesa%20de%20trabajo%201-gpi4VYaa7WEPWa6uKDccdFUDZqdspA.svg"
              alt="Logo"
              className="h-full w-auto object-contain"
            />
            <button className="md:hidden" onClick={toggleMenu}>
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Right section with navigation */}
          <div className={`flex-1 ${isMenuOpen ? "block" : "hidden"} md:block`}>
            {/* Top row with main navigation */}
            <div className="flex flex-col md:flex-row justify-between items-center h-auto md:h-12 px-4 md:px-6 border-b-2 border-black">
              <div className="flex flex-col md:flex-row items-center gap-4 md:gap-8 font-['Saira'] text-sm py-4 md:py-0">
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "home" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onHomeClick)}
                >
                  {t("home")}
                </span>
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "aboutUs" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onAboutUsClick)}
                >
                  {t("aboutUs")}
                </span>
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "contact" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onContactClick)}
                >
                  {t("contact")}
                </span>
              </div>
              <div className="flex flex-col md:flex-row items-center gap-4 py-4 md:py-0">
                <button
                  onClick={() => handleNavClick(onQuickStart)}
                  className={`text-sm font-['Saira'] hover:opacity-70 transition-colors ${activeSection === "quickStart" ? "font-bold" : ""}`}
                >
                  {t("quickStart")}
                </button>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleLanguageChange("en")}
                    className={`text-sm ${language === "en" ? "font-bold" : ""}`}
                  >
                    EN
                  </button>
                  <button
                    onClick={() => handleLanguageChange("es")}
                    className={`text-sm ${language === "es" ? "font-bold" : ""}`}
                  >
                    ES
                  </button>
                  <button
                    onClick={() => handleLanguageChange("zh")}
                    className={`text-sm ${language === "zh" ? "font-bold" : ""}`}
                  >
                    中文
                  </button>
                </div>
              </div>
            </div>

            {/* Bottom row with services */}
            <div className="flex flex-col md:flex-row justify-between items-center h-auto md:h-12 px-4 md:px-6 py-4 md:py-0">
              <div className="flex flex-col md:flex-row items-center gap-4 font-['Saira'] text-sm">
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "software" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onSoftwareClick)}
                >
                  {t("software")}
                </span>
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "design" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onDesignClick)}
                >
                  {t("design")}
                </span>
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "writing" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onWritingClick)}
                >
                  {t("writing")}
                </span>
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "marketing" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onMarketingClick)}
                >
                  {t("marketing")}
                </span>
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "socialMedia" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onSocialMediaClick)}
                >
                  {t("socialMedia")}
                </span>
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "translation" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onTranslationClick)}
                >
                  {t("translation")}
                </span>
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "assistance" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onAssistanceClick)}
                >
                  {t("assistance")}
                </span>
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "video" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onVideoClick)}
                >
                  {t("video")}
                </span>
                <span
                  className={`cursor-pointer hover:opacity-70 ${activeSection === "education" ? "font-bold" : ""}`}
                  onClick={() => handleNavClick(onEducationClick)}
                >
                  {t("education")}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}

