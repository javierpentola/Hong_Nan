import { useLanguage } from "../contexts/LanguageContext"
import { Palette, Users, LineChart, Shield } from "lucide-react"

export function Design() {
  const { t } = useLanguage()

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)] p-8">
      <h1
        className="text-4xl font-bold mb-6 transition-transform duration-300 ease-in-out hover:scale-105"
        dangerouslySetInnerHTML={{ __html: t("designTitle") }}
      />
      <p
        className="text-xl mb-8 max-w-2xl text-center transition-opacity duration-300 ease-in-out hover:opacity-80"
        dangerouslySetInnerHTML={{ __html: t("designDescription") }}
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <div className="flex items-center gap-3 mb-4">
            <Palette className="w-6 h-6" />
            <h2 className="text-2xl font-bold">{t("creativeExcellence")}</h2>
          </div>
          <p>{t("creativeExcellenceDescription")}</p>
        </div>
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <div className="flex items-center gap-3 mb-4">
            <Users className="w-6 h-6" />
            <h2 className="text-2xl font-bold">{t("talentMatching")}</h2>
          </div>
          <p>{t("talentMatchingDescription")}</p>
        </div>
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <div className="flex items-center gap-3 mb-4">
            <LineChart className="w-6 h-6" />
            <h2 className="text-2xl font-bold">{t("competitivePricing")}</h2>
          </div>
          <p>{t("competitivePricingDescription")}</p>
        </div>
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-6 h-6" />
            <h2 className="text-2xl font-bold">{t("qualityGuarantee")}</h2>
          </div>
          <p>{t("qualityGuaranteeDescription")}</p>
        </div>
      </div>
      <div className="mt-12 max-w-2xl text-center">
        <h3 className="text-2xl font-bold mb-4 transition-transform duration-300 ease-in-out hover:scale-105">
          {t("designServices")}
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-left">
          {t("designServicesList").map((service: string, index: number) => (
            <div
              key={index}
              className="p-3 border-2 border-black transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105"
            >
              {service}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

