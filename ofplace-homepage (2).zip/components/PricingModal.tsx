import { useLanguage } from "../contexts/LanguageContext"
import { translations_2 } from "../utils/translations_2"

export function PricingModal() {
  const { language } = useLanguage()
  const t = (key: keyof (typeof translations_2)["en"]) => translations_2[language as keyof typeof translations_2][key]

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-4">{t("pricingTitle")}</h2>
      <p className="mb-6">{t("pricingDescription")}</p>

      <div className="space-y-6">
        <div>
          <h3 className="text-xl font-bold mb-2">{t("monthlyPlan")}</h3>
          <p>{t("monthlyPlanDescription")}</p>
        </div>

        <div>
          <h3 className="text-xl font-bold mb-2">{t("annualPlan")}</h3>
          <p>{t("annualPlanDescription")}</p>
        </div>

        <div>
          <h3 className="text-xl font-bold mb-2">{t("projectBasedPlan")}</h3>
          <p>{t("projectBasedPlanDescription")}</p>
        </div>
      </div>

      <p className="mt-6 font-bold">{t("contactForQuote")}</p>
      <p className="text-sm text-gray-600 mt-4">{t("pricingNote")}</p>
    </div>
  )
}

