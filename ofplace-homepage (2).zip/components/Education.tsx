import { useLanguage } from "../contexts/LanguageContext"
import { BookOpen, Clock, Award, Search, CheckCircle } from "lucide-react"

export function Education() {
  const { t } = useLanguage()

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)] p-8">
      <h1
        className="text-4xl font-bold mb-6 transition-transform duration-300 ease-in-out hover:scale-105"
        dangerouslySetInnerHTML={{ __html: t("educationTitle") }}
      />
      <p
        className="text-xl mb-8 max-w-2xl text-center transition-opacity duration-300 ease-in-out hover:opacity-80"
        dangerouslySetInnerHTML={{ __html: t("educationDescription") }}
      />

      {/* Main content with a different layout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl w-full">
        <div className="md:col-span-2 space-y-8">
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <h2 className="text-2xl font-bold mb-4">{t("findTutor")}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <Search className="w-5 h-5" />
                <span>{t("searchTutors")}</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                <span>{t("verifiedTutors")}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                <span>{t("flexibleScheduling")}</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5" />
                <span>{t("qualityAssurance")}</span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
              <h3 className="text-xl font-bold mb-4">{t("subjects")}</h3>
              <ul className="list-disc pl-5 space-y-2">
                {t("subjectsList").map((subject: string, index: number) => (
                  <li key={index} className="transition-all duration-300 ease-in-out hover:translate-x-2">
                    {subject}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
              <h3 className="text-xl font-bold mb-4">{t("ageGroups")}</h3>
              <ul className="list-disc pl-5 space-y-2">
                {t("ageGroupsList").map((ageGroup: string, index: number) => (
                  <li key={index} className="transition-all duration-300 ease-in-out hover:translate-x-2">
                    {ageGroup}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
        <div className="md:col-span-1 flex flex-col gap-8">
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <h2 className="text-2xl font-bold mb-4">{t("tutorBenefits")}</h2>
            <ul className="space-y-2">
              {t("tutorBenefitsList").map((benefit: string, index: number) => (
                <li key={index} className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4" />
                  <span>{benefit}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="mt-12 max-w-4xl text-center">
        <h3 className="text-2xl font-bold mb-4 transition-transform duration-300 ease-in-out hover:scale-105">
          {t("whyChooseUsEducation")}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {t("whyChooseUsEducationList").map((reason: string, index: number) => (
            <div
              key={index}
              className="p-4 border-2 border-black transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105"
            >
              {reason}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

