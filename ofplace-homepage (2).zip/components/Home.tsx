import { useLanguage } from "../contexts/LanguageContext"
import { Mail } from "lucide-react"

export function Home() {
  const { t } = useLanguage()

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)] p-8">
      <h1
        className="text-4xl font-bold mb-6 transition-transform duration-300 ease-in-out hover:scale-105"
        dangerouslySetInnerHTML={{ __html: t("welcomeHome") }}
      />
      <p
        className="text-xl mb-8 max-w-2xl text-center transition-opacity duration-300 ease-in-out hover:opacity-80"
        dangerouslySetInnerHTML={{ __html: t("homeDescription") }}
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <h2 className="text-2xl font-bold mb-4">{t("forBusinesses")}</h2>
          <p>{t("businessesDescription")}</p>
        </div>
        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <h2 className="text-2xl font-bold mb-4">{t("forFreelancers")}</h2>
          <p>{t("freelancersDescription")}</p>
        </div>
      </div>
      <div className="mt-12 text-center">
        <h3 className="text-2xl font-bold mb-4 transition-transform duration-300 ease-in-out hover:scale-105">
          {t("contactUs")}
        </h3>
        <div className="flex items-center justify-center transition-all duration-300 ease-in-out hover:scale-105">
          <Mail className="mr-2" />
          <a href="mailto:contact@hongnan.com" className="text-xl hover:underline">
            contact@hongnan.com
          </a>
        </div>
        <p className="mt-4 transition-opacity duration-300 ease-in-out hover:opacity-80">{t("contactInstructions")}</p>
      </div>
    </div>
  )
}

