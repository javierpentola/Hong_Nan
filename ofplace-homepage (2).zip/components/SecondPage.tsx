"use client"

import { useState, useEffect } from "react"
import Navbar from "./Navbar"
import { useLanguage } from "../contexts/LanguageContext"
import { Home } from "./Home"
import { AboutUs } from "./AboutUs"
import { Contact } from "./Contact"
import { Software } from "./Software"
import { Design } from "./Design"
import { Writing } from "./Writing"
import { Marketing } from "./Marketing"
import { SocialMedia } from "./SocialMedia"
import { Translation } from "./Translation"
import { Assistance } from "./Assistance"
import { Video } from "./Video"
import { Education } from "./Education"

type ContentSection =
  | "home"
  | "aboutUs"
  | "contact"
  | "quickStart"
  | "software"
  | "design"
  | "writing"
  | "marketing"
  | "socialMedia"
  | "translation"
  | "assistance"
  | "video"
  | "education"
  | null

interface SecondPageProps {
  initialActiveSection: ContentSection
}

export function SecondPage({ initialActiveSection }: SecondPageProps) {
  const { t } = useLanguage()
  const [activeSection, setActiveSection] = useState<ContentSection>(initialActiveSection)
  const [animatingSection, setAnimatingSection] = useState<ContentSection | null>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  const handleSectionToggle = (section: ContentSection) => {
    if (activeSection === section) {
      setAnimatingSection(section)
      setTimeout(() => {
        setActiveSection(null)
        setAnimatingSection(null)
      }, 500) // Match this with the CSS transition duration
    } else {
      setActiveSection(section)
    }
  }

  return (
    <div
      className={`min-h-screen text-black font-['Saira'] transition-opacity duration-1000 ${isVisible ? "opacity-100" : "opacity-0"}`}
    >
      <Navbar
        onQuickStart={() => handleSectionToggle("quickStart")}
        onHomeClick={() => handleSectionToggle("home")}
        onAboutUsClick={() => handleSectionToggle("aboutUs")}
        onContactClick={() => handleSectionToggle("contact")}
        onSoftwareClick={() => handleSectionToggle("software")}
        onDesignClick={() => handleSectionToggle("design")}
        onWritingClick={() => handleSectionToggle("writing")}
        onMarketingClick={() => handleSectionToggle("marketing")}
        onSocialMediaClick={() => handleSectionToggle("socialMedia")}
        onTranslationClick={() => handleSectionToggle("translation")}
        onAssistanceClick={() => handleSectionToggle("assistance")}
        onVideoClick={() => handleSectionToggle("video")}
        onEducationClick={() => handleSectionToggle("education")}
        activeSection={activeSection}
      />
      <div className="pt-24 mobile-padding">
        {(activeSection === "home" || animatingSection === "home") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "home" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <Home />
          </div>
        )}
        {(activeSection === "aboutUs" || animatingSection === "aboutUs") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "aboutUs" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <AboutUs />
          </div>
        )}
        {(activeSection === "contact" || animatingSection === "contact") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "contact" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <Contact />
          </div>
        )}
        {(activeSection === "software" || animatingSection === "software") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "software" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <Software />
          </div>
        )}
        {(activeSection === "design" || animatingSection === "design") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "design" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <Design />
          </div>
        )}
        {(activeSection === "writing" || animatingSection === "writing") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "writing" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <Writing />
          </div>
        )}
        {(activeSection === "marketing" || animatingSection === "marketing") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "marketing" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <Marketing />
          </div>
        )}
        {(activeSection === "socialMedia" || animatingSection === "socialMedia") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "socialMedia" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <SocialMedia />
          </div>
        )}
        {(activeSection === "translation" || animatingSection === "translation") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "translation" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <Translation />
          </div>
        )}
        {(activeSection === "assistance" || animatingSection === "assistance") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "assistance" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <Assistance />
          </div>
        )}
        {(activeSection === "video" || animatingSection === "video") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "video" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <Video />
          </div>
        )}
        {(activeSection === "education" || animatingSection === "education") && (
          <div
            className={`transition-all duration-500 ease-in-out ${activeSection === "education" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <Education />
          </div>
        )}
        {(activeSection === "quickStart" || animatingSection === "quickStart") && (
          <div
            className={`flex flex-col md:flex-row justify-center items-start pt-8 transition-all duration-500 ease-in-out ${activeSection === "quickStart" ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}
          >
            <div
              className="w-full md:w-[calc(25%-2rem)] h-auto md:h-[400px] border-2 border-black bg-white p-4 md:p-8 mb-4 md:mb-0 md:mr-4
                transition-all duration-1000 ease-in-out"
            >
              <div className="text-2xl md:text-4xl font-bold whitespace-pre-line">{t("makeSimple")}</div>
            </div>
            <div
              className="w-full md:w-[calc(75%-4rem)] h-auto md:h-[400px] border-2 border-black bg-white
                transition-all duration-1000 ease-in-out flex flex-col md:flex-row"
            >
              <div className="flex-1 p-4 md:p-8">
                <p className="text-sm md:text-base mb-4 md:mb-6">{t("companyDescription")}</p>
                <div>
                  <p className="text-sm md:text-base font-bold mb-2 md:mb-4">{t("services")}</p>
                  <div className="grid grid-cols-2 gap-x-4 md:gap-x-8 gap-y-1 md:gap-y-2">
                    {t("servicesList").map((service: string, index: number) => (
                      <div key={index} className="text-xs md:text-base">
                        {service}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="w-full md:w-[300px] h-[200px] md:h-auto border-t-2 md:border-t-0 md:border-l-2 border-black flex items-center justify-center text-gray-400">
                Image Placeholder
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

