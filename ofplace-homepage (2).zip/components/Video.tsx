import { useLanguage } from "../contexts/LanguageContext"
import { Film, Edit, Tv, Music } from "lucide-react"

export function Video() {
  const { t } = useLanguage()

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)] p-8">
      <h1
        className="text-4xl font-bold mb-6 transition-transform duration-300 ease-in-out hover:scale-105"
        dangerouslySetInnerHTML={{ __html: t("videoTitle") }}
      />
      <p
        className="text-xl mb-8 max-w-2xl text-center transition-opacity duration-300 ease-in-out hover:opacity-80"
        dangerouslySetInnerHTML={{ __html: t("videoDescription") }}
      />

      {/* Main content with a different layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl w-full">
        <div className="col-span-1 md:col-span-2 border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <h2 className="text-2xl font-bold mb-4">{t("videoEditingServices")}</h2>
          <p className="mb-4">{t("videoEditingDescription")}</p>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2">
              <Film className="w-5 h-5" />
              <span>{t("filmEditing")}</span>
            </div>
            <div className="flex items-center gap-2">
              <Edit className="w-5 h-5" />
              <span>{t("videoPostProduction")}</span>
            </div>
            <div className="flex items-center gap-2">
              <Tv className="w-5 h-5" />
              <span>{t("motionGraphics")}</span>
            </div>
            <div className="flex items-center gap-2">
              <Music className="w-5 h-5" />
              <span>{t("soundEditing")}</span>
            </div>
          </div>
        </div>

        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <h2 className="text-2xl font-bold mb-4">{t("videoProjects")}</h2>
          <ul className="list-disc pl-5 space-y-2">
            {t("videoProjectsList").map((project: string, index: number) => (
              <li key={index} className="transition-all duration-300 ease-in-out hover:translate-x-2">
                {project}
              </li>
            ))}
          </ul>
        </div>

        <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
          <h2 className="text-2xl font-bold mb-4">{t("videoExperts")}</h2>
          <p className="mb-4">{t("videoExpertsDescription")}</p>
          <ul className="list-disc pl-5 space-y-2">
            {t("videoExpertiseList").map((expertise: string, index: number) => (
              <li key={index} className="transition-all duration-300 ease-in-out hover:translate-x-2">
                {expertise}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-12 max-w-4xl text-center">
        <h3 className="text-2xl font-bold mb-4 transition-transform duration-300 ease-in-out hover:scale-105">
          {t("whyChooseUsVideo")}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {t("whyChooseUsVideoList").map((reason: string, index: number) => (
            <div
              key={index}
              className="p-4 border-2 border-black transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105"
            >
              {reason}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

