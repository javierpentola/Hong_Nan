"use client"

import { useLanguage } from "../contexts/LanguageContext"
import { translations_3 } from "../utils/translations_3"
import { Globe, Users, Zap, Clock } from "lucide-react"

export function Translation() {
  const { language } = useLanguage()
  const t = translations_3[language as keyof typeof translations_3].translationServices

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)] p-8">
      <h1
        className="text-4xl font-bold mb-6 transition-transform duration-300 ease-in-out hover:scale-105"
        dangerouslySetInnerHTML={{ __html: t.title }}
      />
      <p className="text-xl mb-8 max-w-2xl text-center transition-opacity duration-300 ease-in-out hover:opacity-80">
        {t.description}
      </p>
      <p className="text-xl mb-8 max-w-2xl text-center font-bold">{t.legalAuthorization}</p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl w-full">
        <div className="md:col-span-2 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
              <div className="flex items-center gap-3 mb-4">
                <Globe className="w-6 h-6" />
                <h2 className="text-2xl font-bold">{t.languagePairs.title}</h2>
              </div>
              <p>{t.languagePairs.description}</p>
            </div>
            <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
              <div className="flex items-center gap-3 mb-4">
                <Users className="w-6 h-6" />
                <h2 className="text-2xl font-bold">{t.expertTranslators.title}</h2>
              </div>
              <p>{t.expertTranslators.description}</p>
            </div>
          </div>
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <div className="flex items-center gap-3 mb-4">
              <Zap className="w-6 h-6" />
              <h2 className="text-2xl font-bold">{t.specializedTranslation.title}</h2>
            </div>
            <p>{t.specializedTranslation.description}</p>
          </div>
        </div>
        <div className="md:col-span-1 flex flex-col">
          <div className="border-2 border-black p-6 mb-8 flex-grow transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <div className="flex items-center gap-3 mb-4">
              <Clock className="w-6 h-6" />
              <h2 className="text-2xl font-bold">{t.turnaroundTime.title}</h2>
            </div>
            <p>{t.turnaroundTime.description}</p>
          </div>
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <h3 className="text-2xl font-bold mb-4 transition-transform duration-300 ease-in-out hover:scale-105">
              {t.services.title}
            </h3>
            <ul className="space-y-2">
              {t.services.list.map((service: string, index: number) => (
                <li
                  key={index}
                  className="p-2 border-b border-gray-200 last:border-b-0 transition-all duration-300 ease-in-out hover:bg-gray-50"
                >
                  {service}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

