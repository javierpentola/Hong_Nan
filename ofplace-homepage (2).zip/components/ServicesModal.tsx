import React from "react"

export function ServicesModal() {
  return (
    <ul className="list-disc pl-5">
      <li>AI-powered solutions</li>
      <li>Cloud computing and infrastructure</li>
      <li>Data analytics and visualization</li>
      <li>Custom software development</li>
    </ul>
  )
}

