import { useEffect, useState } from "react"
import { AboutModal } from "./AboutModal"
import { ServicesModal } from "./ServicesModal"
import { PricingModal } from "./PricingModal"
import { TestimonialsModal } from "./TestimonialsModal"
import { OurFocusModal } from "./OurFocusModal"

interface ModalProps {
  isOpen: boolean
  onClose: () => void
  variant: "about" | "services" | "pricing" | "testimonials" | "ourFocus"
}

export function Modal({ isOpen, onClose, variant }: ModalProps) {
  const [isAnimating, setIsAnimating] = useState(false)
  const [isFullyOpen, setIsFullyOpen] = useState(false)

  useEffect(() => {
    if (isOpen) {
      setIsAnimating(true)
      setTimeout(() => setIsFullyOpen(true), 50) // Start expansion after a short delay
    } else {
      setIsFullyOpen(false)
      const timer = setTimeout(() => setIsAnimating(false), 500)
      return () => clearTimeout(timer)
    }
  }, [isOpen])

  const getBorderClasses = () => {
    switch (variant) {
      case "about":
        return "border-t-2 border-l-2 border-black"
      case "services":
        return "border-t-2 border-r-2 border-black"
      case "pricing":
        return "border-b-2 border-l-2 border-black"
      case "testimonials":
        return "border-b-2 border-r-2 border-black"
      case "ourFocus":
        return "border-t-2 border-r-2 border-black"
      default:
        return ""
    }
  }

  const getContent = () => {
    switch (variant) {
      case "about":
        return <AboutModal />
      case "services":
        return <ServicesModal />
      case "pricing":
        return <PricingModal />
      case "testimonials":
        return <TestimonialsModal />
      case "ourFocus":
        return <OurFocusModal />
      default:
        return null
    }
  }

  if (!isOpen && !isAnimating) return null

  return (
    <div
      className={`fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center transition-opacity duration-500 ease-in-out z-50 ${
        isAnimating ? "opacity-100" : "opacity-0"
      }`}
      onClick={onClose}
    >
      <div
        className={`bg-white shadow-xl overflow-hidden transition-all duration-500 ease-in-out ${getBorderClasses()} ${
          isFullyOpen ? "opacity-100 scale-100 max-w-md w-full p-6" : "opacity-0 scale-0 w-0 h-0 p-0"
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className={`transition-opacity duration-500 ease-in-out ${isFullyOpen ? "opacity-100" : "opacity-0"}`}>
          {getContent()}
          <div className="flex justify-center mt-4">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gray-200 text-gray-800 hover:bg-gray-300 transition-colors rounded"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

