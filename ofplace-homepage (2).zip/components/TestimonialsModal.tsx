import React from "react"
import { useLanguage } from "../contexts/LanguageContext"

export function TestimonialsModal() {
  const { t } = useLanguage()

  return (
    <div className="space-y-6">
      {t("testimonialsList").map((testimonial: { quote: string; author: string; role: string }, index: number) => (
        <div key={index} className="border-l-4 border-black pl-4">
          <blockquote className="italic mb-2">"{testimonial.quote}"</blockquote>
          <p className="font-bold">{testimonial.author}</p>
          <p className="text-sm text-gray-600">{testimonial.role}</p>
        </div>
      ))}
    </div>
  )
}

