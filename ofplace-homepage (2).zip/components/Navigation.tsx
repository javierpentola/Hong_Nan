"use client"
import { useLanguage } from "../contexts/LanguageContext"

interface NavigationProps {
  openModal: (modalName: string) => void
  animationStep: number
}

export function Navigation({ openModal, animationStep }: NavigationProps) {
  const { t } = useLanguage()

  return (
    <nav className="flex flex-col md:flex-row justify-between w-full font-['Saira'] tracking-wider">
      <button
        onClick={() => openModal("about")}
        className={`px-4 py-2 border-2 border-black hover:bg-black hover:text-white transition-all duration-500 mb-4 md:mb-0 ${
          animationStep >= 2 ? "-translate-y-full opacity-0" : ""
        }`}
      >
        {t("whoWeAre")}
      </button>
      <button
        onClick={() => openModal("ourFocus")}
        className={`px-4 py-2 border-2 border-black hover:bg-black hover:text-white transition-all duration-500 ${
          animationStep >= 3 ? "translate-x-full opacity-0" : ""
        }`}
      >
        {t("ourFocus")}
      </button>
    </nav>
  )
}

