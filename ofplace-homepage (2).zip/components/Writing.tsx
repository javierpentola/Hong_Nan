import { useLanguage } from "../contexts/LanguageContext"
import { PenTool, Users, LineChart, Shield } from "lucide-react"

export function Writing() {
  const { t } = useLanguage()

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)] p-8">
      <h1
        className="text-4xl font-bold mb-6 transition-transform duration-300 ease-in-out hover:scale-105"
        dangerouslySetInnerHTML={{ __html: t("writingTitle") }}
      />
      <p
        className="text-xl mb-8 max-w-2xl text-center transition-opacity duration-300 ease-in-out hover:opacity-80"
        dangerouslySetInnerHTML={{ __html: t("writingDescription") }}
      />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
        <div className="space-y-6">
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <div className="flex items-center gap-3 mb-4">
              <PenTool className="w-6 h-6" />
              <h2 className="text-2xl font-bold">{t("expertWriters")}</h2>
            </div>
            <p>{t("expertWritersDescription")}</p>
          </div>
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <div className="flex items-center gap-3 mb-4">
              <Users className="w-6 h-6" />
              <h2 className="text-2xl font-bold">{t("tailoredContent")}</h2>
            </div>
            <p>{t("tailoredContentDescription")}</p>
          </div>
        </div>
        <div className="space-y-6">
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <div className="flex items-center gap-3 mb-4">
              <LineChart className="w-6 h-6" />
              <h2 className="text-2xl font-bold">{t("competitiveRates")}</h2>
            </div>
            <p>{t("competitiveRatesDescription")}</p>
          </div>
          <div className="border-2 border-black p-6 transition-all duration-300 ease-in-out hover:shadow-lg hover:scale-105">
            <div className="flex items-center gap-3 mb-4">
              <Shield className="w-6 h-6" />
              <h2 className="text-2xl font-bold">{t("qualityAssurance")}</h2>
            </div>
            <p>{t("qualityAssuranceDescription")}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

