export const translations_3 = {
  en: {
    softwareServices: {
      title: 'Our <span class="underline">Software</span> Services',
      description:
        "At Hong Nan, we specialize in connecting businesses with top-tier software development talent. Our platform streamlines the process of finding, pricing, and delivering high-quality software solutions.",
      webDevelopment: {
        title: "Web Development",
        description: "Full-stack web applications using modern frameworks and cutting-edge technologies",
      },
      mobileDevelopment: {
        title: "Mobile Development",
        description: "Native and cross-platform mobile applications for iOS and Android",
      },
      databaseManagement: {
        title: "Database Management",
        description: "Efficient data storage, retrieval, and management solutions for your business",
      },
      cloudServices: {
        title: "Cloud Services",
        description: "Scalable cloud infrastructure and deployment solutions",
      },
      customSoftware: {
        title: "Custom Software",
        description: "Bespoke software solutions tailored to your specific business needs",
      },
      cybersecurity: {
        title: "Cybersecurity",
        description: "Comprehensive security solutions to protect your digital assets",
      },
    },
    socialMediaServices: {
      title: 'Our <span class="underline">Social Media</span> Services',
      description:
        "Hong Nan connects you with expert social media professionals. We curate and manage relationships between businesses and skilled social media managers, ensuring impactful online presence and engagement.",
      contentCreation: {
        title: "Content Creation",
        description:
          "Strategic content creation tailored to each platform, ensuring maximum engagement and brand consistency",
      },
      communityManagement: {
        title: "Community Management",
        description:
          "Proactive engagement with your audience, building strong relationships and fostering meaningful interactions",
      },
      analytics: {
        title: "Analytics & Performance",
        description:
          "Comprehensive analytics and regular reports to track performance, including SEO metrics, engagement rates, and ROI analysis",
      },
      advertising: {
        title: "Targeted Campaigns",
        description:
          "Strategic ad campaigns designed to reach your ideal audience and achieve specific marketing objectives",
      },
      platforms: {
        title: "Platforms We Cover",
        list: ["Facebook", "Instagram", "Twitter", "LinkedIn", "TikTok", "YouTube", "Pinterest", "Snapchat"],
      },
    },
    translationServices: {
      title: 'Our <span class="underline">Translation</span> Services',
      description:
        "Hong Nan connects you with expert translators worldwide. We curate and manage relationships between businesses and skilled linguists, ensuring accurate and culturally appropriate translations.",
      legalAuthorization:
        "We ensure that EVERY SINGLE TRANSLATOR is legally authorized by the country where the language is official.",
      languagePairs: {
        title: "Language Pairs",
        description:
          "We offer translation services for a wide range of language pairs, covering major global languages and regional dialects.",
      },
      expertTranslators: {
        title: "Expert Translators",
        description:
          "Our network includes professional translators with expertise in various fields, ensuring accurate and context-appropriate translations.",
      },
      specializedTranslation: {
        title: "Specialized Translation",
        description:
          "We provide specialized translation services for technical, legal, medical, and other industry-specific content.",
      },
      turnaroundTime: {
        title: "Quick Turnaround",
        description:
          "We offer flexible turnaround times to meet your deadlines, including express translation services for urgent projects.",
      },
      services: {
        title: "Our Translation Offerings",
        list: [
          "Document Translation",
          "Website Localization",
          "Software Localization",
          "Subtitling & Captioning",
          "Interpretation Services",
          "Transcreation",
          "Machine Translation Post-Editing",
          "Certified Translation",
          "Multilingual DTP",
        ],
      },
    },
  },
  es: {
    softwareServices: {
      title: 'Nuestros Servicios de <span class="underline">Software</span>',
      description:
        "En Hong Nan, nos especializamos en conectar empresas con talento de desarrollo de software de primer nivel. Nuestra plataforma simplifica el proceso de encontrar, cotizar y entregar soluciones de software de alta calidad.",
      webDevelopment: {
        title: "Desarrollo Web",
        description: "Aplicaciones web full-stack utilizando frameworks modernos y tecnologías de vanguardia",
      },
      mobileDevelopment: {
        title: "Desarrollo Móvil",
        description: "Aplicaciones móviles nativas y multiplataforma para iOS y Android",
      },
      databaseManagement: {
        title: "Gestión de Bases de Datos",
        description: "Soluciones eficientes de almacenamiento, recuperación y gestión de datos para su negocio",
      },
      cloudServices: {
        title: "Servicios en la Nube",
        description: "Soluciones escalables de infraestructura y despliegue en la nube",
      },
      customSoftware: {
        title: "Software Personalizado",
        description: "Soluciones de software a medida adaptadas a las necesidades específicas de su negocio",
      },
      cybersecurity: {
        title: "Ciberseguridad",
        description: "Soluciones de seguridad integrales para proteger sus activos digitales",
      },
    },
    socialMediaServices: {
      title: 'Nuestros Servicios de <span class="underline">Redes Sociales</span>',
      description:
        "Hong Nan te conecta con profesionales expertos en redes sociales. Seleccionamos y gestionamos las relaciones entre empresas y gestores de redes sociales cualificados, asegurando una presencia online impactante y un alto nivel de engagement.",
      contentCreation: {
        title: "Creación de Contenido",
        description:
          "Creación estratégica de contenido adaptado a cada plataforma, garantizando máximo engagement y consistencia de marca",
      },
      communityManagement: {
        title: "Gestión de Comunidad",
        description:
          "Participación proactiva con tu audiencia, construyendo relaciones sólidas y fomentando interacciones significativas",
      },
      analytics: {
        title: "Análisis y Rendimiento",
        description:
          "Análisis completo e informes regulares para seguir el rendimiento, incluyendo métricas SEO, tasas de engagement y análisis de ROI",
      },
      advertising: {
        title: "Campañas Dirigidas",
        description:
          "Campañas publicitarias estratégicas diseñadas para alcanzar a tu audiencia ideal y lograr objetivos específicos de marketing",
      },
      platforms: {
        title: "Plataformas que Cubrimos",
        list: ["Facebook", "Instagram", "Twitter", "LinkedIn", "TikTok", "YouTube", "Pinterest", "Snapchat"],
      },
    },
    translationServices: {
      title: 'Nuestros Servicios de <span class="underline">Traducción</span>',
      description:
        "Hong Nan te conecta con traductores expertos de todo el mundo. Seleccionamos y gestionamos las relaciones entre empresas y lingüistas cualificados, garantizando traducciones precisas y culturalmente apropiadas.",
      legalAuthorization:
        "Nos aseguramos de que CADA TRADUCTOR esté legalmente autorizado por el país donde el idioma es oficial.",
      languagePairs: {
        title: "Pares de Idiomas",
        description:
          "Ofrecemos servicios de traducción para una amplia gama de pares de idiomas, cubriendo los principales idiomas globales y dialectos regionales.",
      },
      expertTranslators: {
        title: "Traductores Expertos",
        description:
          "Nuestra red incluye traductores profesionales con experiencia en diversos campos, garantizando traducciones precisas y apropiadas al contexto.",
      },
      specializedTranslation: {
        title: "Traducción Especializada",
        description:
          "Proporcionamos servicios de traducción especializada para contenido técnico, legal, médico y otros contenidos específicos de la industria.",
      },
      turnaroundTime: {
        title: "Entrega Rápida",
        description:
          "Ofrecemos tiempos de entrega flexibles para cumplir con sus plazos, incluyendo servicios de traducción express para proyectos urgentes.",
      },
      services: {
        title: "Nuestros Servicios de Traducción",
        list: [
          "Traducción de Documentos",
          "Localización de Sitios Web",
          "Localización de Software",
          "Subtitulado y Subtítulos",
          "Servicios de Interpretación",
          "Transcreación",
          "Post-edición de Traducción Automática",
          "Traducción Certificada",
          "DTP Multilingüe",
        ],
      },
    },
  },
  zh: {
    softwareServices: {
      title: '我们的<span class="underline">软件</span>服务',
      description:
        "在红南，我们专注于将企业与顶级软件开发人才联系起来。我们的平台简化了寻找、定价和交付高质量软件解决方案的过程。",
      webDevelopment: {
        title: "网络开发",
        description: "使用现代框架和前沿技术的全栈网络应用",
      },
      mobileDevelopment: {
        title: "移动开发",
        description: "iOS和Android的原生和跨平台移动应用",
      },
      databaseManagement: {
        title: "数据库管理",
        description: "为您的企业提供高效的数据存储、检索和管理解决方案",
      },
      cloudServices: {
        title: "云服务",
        description: "可扩展的云基础设施和部署解决方案",
      },
      customSoftware: {
        title: "定制软件",
        description: "根据您的具体业务需求定制的软件解决方案",
      },
      cybersecurity: {
        title: "网络安全",
        description: "全面的安全解决方案，保护您的数字资产",
      },
    },
    socialMediaServices: {
      title: '我们的<span class="underline">社交媒体</span>服务',
      description:
        "红南将您与社交媒体专家联系起来。我们精心策划和管理企业与专业社交媒体经理之间的关系，确保有影响力的在线存在和互动。",
      contentCreation: {
        title: "内容创作",
        description: "针对每个平台量身定制的战略内容创作，确保最大程度的参与度和品牌一致性",
      },
      communityManagement: {
        title: "社区管理",
        description: "与您的受众积极互动，建立牢固的关系并促进有意义的互动",
      },
      analytics: {
        title: "分析与性能",
        description: "全面的分析和定期报告，跟踪包括SEO指标、参与率和投资回报率分析在内的性能",
      },
      advertising: {
        title: "定向广告",
        description: "旨在触及您的目标受众并实现特定营销目标的战略广告活动",
      },
      platforms: {
        title: "我们覆盖的平台",
        list: ["Facebook", "Instagram", "Twitter", "领英", "抖音", "YouTube", "Pinterest", "Snapchat"],
      },
    },
    translationServices: {
      title: '我们的<span class="underline">翻译</span>服务',
      description:
        "红南将您与全球专业翻译人员联系起来。我们精心策划和管理企业与熟练语言专家之间的关系，确保准确和文化适当的翻译。",
      legalAuthorization: "我们确保每一位翻译人员都得到该语言官方使用国家的法律授权。",
      languagePairs: {
        title: "语言对",
        description: "我们提供广泛的语言对翻译服务，涵盖主要的全球语言和地区方言。",
      },
      expertTranslators: {
        title: "专业翻译",
        description: "我们的网络包括各个领域的专业翻译人员，确保准确和符合上下文的翻译。",
      },
      specializedTranslation: {
        title: "专业翻译",
        description: "我们为技术、法律、医疗和其他行业特定内容提供专业翻译服务。",
      },
      turnaroundTime: {
        title: "快速周转",
        description: "我们提供灵活的周转时间以满足您的截止日期，包括紧急项目的快速翻译服务。",
      },
      services: {
        title: "我们的翻译服务",
        list: [
          "文件翻译",
          "网站本地化",
          "软件本地化",
          "字幕制作",
          "口译服务",
          "创意翻译",
          "机器翻译后编辑",
          "认证翻译",
          "多语言桌面排版",
        ],
      },
    },
  },
}

export type Language_3 = keyof typeof translations_3

